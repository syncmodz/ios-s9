/*
 * Compile Apple's HFS kext sources inside SWEET the way the kext is built:
 * with the kext (KPI) view of the kernel headers, and with only HFS's own
 * kext-config.h deciding features. The kernel's -DCONFIG_* options are not
 * visible to a kext build, so the ones HFS tests are cleared first. SWEET
 * has no AppleKeyStore, so content protection stays off.
 */
#ifndef SWEET_HFS_COMPAT_H
#define SWEET_HFS_COMPAT_H
#undef BSD_KERNEL_PRIVATE
#undef XNU_KERNEL_PRIVATE
#undef CONFIG_PROTECT
#undef CONFIG_SEARCHFS
#undef CONFIG_HFS_DIRLINK
#undef CONFIG_SECLUDED_RENAME
#undef CONFIG_MACF
#undef CONFIG_HFS_RBTREE
#undef QUOTA
#undef NAMEDSTREAMS
#undef FIFO
#undef HFS_COMPRESSION
#include "core/kext-config.h"

/* Built in, not a loadable kext (see sweet_hfs_iokit.c). */
#define OSKextGetCurrentLoadTag sweet_hfs_current_load_tag

/*
 * SWEET (7195 port): the 8796 line has typed kalloc (kalloc_type, IOMallocType
 * in IOLib.h). This line predates it, so HFS sees plain typed wrappers over
 * IOMalloc/IOFree. HFS only needs fixed-size, zeroed, type-cast allocations;
 * the type-safety accounting is a hardening feature, not a correctness one.
 */
#ifndef IOMallocType
#define IOMallocType(type)     ((type *)IOMallocZero(sizeof(type)))
#define IOFreeType(elem, type) do { void *__e = (void *)(elem); IOFree(__e, sizeof(type)); } while (0)
#endif

/*
 * Same for the data-buffer spellings. This compat header undefines
 * XNU_KERNEL_PRIVATE, so IOLib.h does not expose them; HFS only needs "zeroed
 * allocation of type*count bytes", which IOMallocZero already provides.
 */
#ifndef IOMallocData
#define IOMallocData(size)     IOMallocZero(size)
#endif
#ifndef IOMallocZeroData
#define IOMallocZeroData(size) IOMallocZero(size)
#endif
#ifndef IOFreeData
#define IOFreeData(elem, size) do { void *__e = (void *)(elem); IOFree(__e, (size)); } while (0)
#endif
#ifndef IONewData
#define IONewData(type, count)     ((type *)IOMallocZero(sizeof(type) * (count)))
#endif
#ifndef IONewZeroData
#define IONewZeroData(type, count) ((type *)IOMallocZero(sizeof(type) * (count)))
#endif
#ifndef IODeleteData
#define IODeleteData(elem, type, count) \
	do { void *__e = (void *)(elem); IOFree(__e, sizeof(type) * (count)); } while (0)
#endif

/*
 * IONew / IONewZero / IODelete / IOSafeDeleteNULL now come from IOLib.h with
 * the 8796 arity dispatch, so nothing is needed here.
 */
#endif
