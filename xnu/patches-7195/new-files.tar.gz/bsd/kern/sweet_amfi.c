/*
 * Built-in AMFI interface for SWEET.
 *
 * On Apple platforms AppleMobileFileIntegrity registers this interface and
 * provides entitlements through the closed CoreEntitlements library. SWEET
 * has neither, and code signing reaches it on every exec (ubc_cs_blob_add).
 *
 * Entitlements: when a code signature is added, its XML entitlements blob
 * (already checked against the code directory) is parsed into a
 * SweetEntitlements object (iokit/Kernel/arm/SweetEntitlements.cpp), set as
 * the blob's csb_entitlements, and every query is answered from it. DER-only
 * signatures get none. Code signature and page hash validation stay with the
 * kernel. Trust caches remain unavailable (no Image4), so the TrustCache
 * interface is left at version 0.
 *
 * Platform binaries: AMFI marks binaries whose cdhash is in a trust cache
 * as platform binaries from its vnode_check_signature MAC hook. Without
 * trust caches, the SWEET policy below marks every binary on the root
 * filesystem instead (the iOS system binaries are ad-hoc signed and are
 * platform binaries only through the static trust cache).
 *
 * Interfaces no kernel path uses on SWEET (they serve other Apple kexts)
 * panic with a clear message instead of being NULL.
 */
#if defined(ARM64_BOARD_CONFIG_SWEET)
#include <kern/debug.h>
#include <kern/startup.h>
#include <libkern/amfi/amfi.h>
#include <mach/kern_return.h>
#include <sys/codesign.h>
#include <sys/mount.h>
#include <sys/priv.h>
#include <sys/proc.h>
#include <sys/systm.h>
#include <sys/ubc_internal.h>
#include <sys/vnode.h>
#include <security/mac_policy.h>

/* iokit/Kernel/arm/SweetEntitlements.cpp */
void *sweet_entitlements_create(const CS_GenericBlob *blob, size_t blob_len);
void *sweet_entitlements_copy_dict(const void *ent);
bool sweet_entitlements_copy_xml(const void *ent, CS_GenericBlob **out);
bool sweet_entitlements_bool(const void *ent, const char *name);
bool sweet_entitlements_string(const void *ent, const char *name, const char *value);
void *sweet_entitlements_copy_object(const void *ent, const char *name);
unsigned int sweet_entitlements_count(const void *ent);
extern void osobject_release(void *object);
extern void osobject_retain(void *object);

/* boot-arg sweet_amfi_debug=1: log the entitlements attached to each signature. */
static TUNABLE(uint32_t, sweet_amfi_debug, "sweet_amfi_debug", 0);

/* The entitlements object of a process's main binary, or NULL. */
static void *
sweet_proc_entitlements(proc_t proc)
{
	struct cs_blob *blob = csproc_get_blob(proc);
	/* SWEET (7195 port): this line has no csblob_os_entitlements_get; the
	 * 8796 helper is exactly this field read. */
	return blob != NULL ? blob->csb_entitlements : NULL;
}

static void
sweet_amfi_entitlements_invalidate(__unused void *os_entitlements)
{
	/* Queries already require a valid signature (csblob_get_entitlements). */
}

static void *
sweet_amfi_entitlements_as_dict(void *os_entitlements)
{
	return sweet_entitlements_copy_dict(os_entitlements);
}

static CEError_t
sweet_amfi_entitlements_query(__unused void *os_entitlements,
    __unused uint8_t cdhash[CS_CDHASH_LEN], __unused CEQuery_t query,
    __unused size_t query_length)
{
	panic("SWEET AMFI: CoreEntitlements queries are not implemented");
}

static bool
sweet_amfi_entitlements_get_transmuted(__unused void *os_entitlements,
    __unused const CS_GenericBlob **blob)
{
	return false;
}

static bool
sweet_amfi_entitlements_get_xml(void *os_entitlements, CS_GenericBlob **blob)
{
	return sweet_entitlements_copy_xml(os_entitlements, blob);
}

static bool
sweet_amfi_get_legacy_profile_exemptions(__unused const uint8_t **profile,
    __unused size_t *profile_length)
{
	return false;
}

static bool
sweet_amfi_get_udid(__unused const uint8_t **udid, __unused size_t *udid_length)
{
	return false;
}

static void *
sweet_amfi_query_context_to_object(__unused CEQueryContext_t ctx)
{
	panic("SWEET AMFI: CoreEntitlements query contexts are not implemented");
}

static kern_return_t
sweet_amfi_adjust_with_monitor(__unused void *os_entitlements,
    __unused const CEQueryContext_t ce_ctx, __unused const void *monitor_sig_obj,
    __unused const char *identity, __unused const uint32_t code_signing_flags)
{
	/* SWEET has no code signing monitor. */
	return KERN_NOT_SUPPORTED;
}

/*
 * Attach the parsed XML entitlements to a code signature being added. This
 * must happen in the vnode_check_signature MAC hook, like AMFI does: later,
 * converting a 4K-page signature to multilevel hashes drops the XML blob.
 * Nothing is granted when the blob is missing, unreadable or does not match
 * its code directory hash.
 */
static void
sweet_amfi_attach_entitlements(struct cs_blob *code_signing_blob)
{
	void *xml = NULL;
	size_t xml_len = 0;

	if (csblob_get_entitlements(code_signing_blob, &xml, &xml_len) != 0) {
		printf("SWEET AMFI: %s: entitlements do not match the code directory, granting none\n",
		    csblob_get_identity(code_signing_blob));
		return;
	}
	if (xml == NULL) {
		return;                 /* no XML entitlements */
	}
	void *ent = sweet_entitlements_create(xml, xml_len);
	if (ent == NULL) {
		printf("SWEET AMFI: %s: unreadable entitlements (%zu bytes), granting none\n",
		    csblob_get_identity(code_signing_blob), xml_len);
		return;
	}
	if (sweet_amfi_debug) {
		/* The test keys only exist in tools/mkinit.py test signatures. */
		printf("SWEET AMFI: %s: %u entitlements (test: bool %d string %d array %d)\n",
		    csblob_get_identity(code_signing_blob), sweet_entitlements_count(ent),
		    sweet_entitlements_bool(ent, "com.apple.private.sweet.test-bool"),
		    sweet_entitlements_string(ent, "com.apple.private.sweet.test-string", "hello"),
		    sweet_entitlements_string(ent, "com.apple.private.sweet.test-array", "two"));
	}
	/*
	 * SWEET (7195 port): this line has no csblob_os_entitlements_set. It is
	 * the same three statements as kern_cs.c in the 8796 line: take a
	 * reference and publish it on the blob.
	 */
	assert(code_signing_blob->csb_entitlements == NULL);
	if (ent) {
		osobject_retain(ent);
	}
	code_signing_blob->csb_entitlements = ent;
	osobject_release(ent);
}

static kern_return_t
sweet_amfi_adjust_without_monitor(__unused void *os_entitlements,
    __unused struct cs_blob *code_signing_blob)
{
	/* Entitlements were attached in sweet_amfi_vnode_check_signature. */
	return KERN_SUCCESS;
}

static kern_return_t
sweet_amfi_query_boolean(const void *os_entitlements, const char *entitlement_name)
{
	return sweet_entitlements_bool(os_entitlements, entitlement_name) ? KERN_SUCCESS : KERN_DENIED;
}

static kern_return_t
sweet_amfi_query_boolean_with_proc(const proc_t proc, const char *entitlement_name)
{
	return sweet_amfi_query_boolean(sweet_proc_entitlements(proc), entitlement_name);
}

static kern_return_t
sweet_amfi_query_string(const void *os_entitlements,
    const char *entitlement_name, const char *entitlement_value)
{
	return sweet_entitlements_string(os_entitlements, entitlement_name, entitlement_value) ?
	       KERN_SUCCESS : KERN_DENIED;
}

static kern_return_t
sweet_amfi_query_string_with_proc(const proc_t proc,
    const char *entitlement_name, const char *entitlement_value)
{
	return sweet_amfi_query_string(sweet_proc_entitlements(proc), entitlement_name,
	           entitlement_value);
}

static kern_return_t
sweet_amfi_copy_object(const void *os_entitlements,
    const char *entitlement_name, void **entitlement_object)
{
	void *obj = sweet_entitlements_copy_object(os_entitlements, entitlement_name);
	if (entitlement_object) {
		*entitlement_object = obj;
	} else if (obj) {
		osobject_release(obj);
	}
	/* SWEET (7195 port): this line has no KERN_NOT_FOUND; callers treat both
	 * codes as a lookup failure. */
	return obj ? KERN_SUCCESS : KERN_FAILURE;
}

static kern_return_t
sweet_amfi_copy_object_with_proc(const proc_t proc,
    const char *entitlement_name, void **entitlement_object)
{
	return sweet_amfi_copy_object(sweet_proc_entitlements(proc), entitlement_name,
	           entitlement_object);
}

static const amfi_t sweet_amfi = {
	.OSEntitlements_invalidate = sweet_amfi_entitlements_invalidate,
	.OSEntitlements_asdict = sweet_amfi_entitlements_as_dict,
	.OSEntitlements_query = sweet_amfi_entitlements_query,
	.OSEntitlements_get_transmuted = sweet_amfi_entitlements_get_transmuted,
	.OSEntitlements_get_xml = sweet_amfi_entitlements_get_xml,
	/* CoreEntitlements is only used by the PMAP_CS code signing monitor. */
	.get_legacy_profile_exemptions = sweet_amfi_get_legacy_profile_exemptions,
	.get_udid = sweet_amfi_get_udid,
	.query_context_to_object = sweet_amfi_query_context_to_object,
	/* .TrustCache stays version 0: trust caches are unavailable without Image4. */
	.OSEntitlements = {
		.version = OSENTITLEMENTS_INTERFACE_VERSION,
		.adjustContextWithMonitor = sweet_amfi_adjust_with_monitor,
		.adjustContextWithoutMonitor = sweet_amfi_adjust_without_monitor,
		.queryEntitlementBoolean = sweet_amfi_query_boolean,
		.queryEntitlementBooleanWithProc = sweet_amfi_query_boolean_with_proc,
		.queryEntitlementString = sweet_amfi_query_string,
		.queryEntitlementStringWithProc = sweet_amfi_query_string_with_proc,
		.copyEntitlementAsOSObject = sweet_amfi_copy_object,
		.copyEntitlementAsOSObjectWithProc = sweet_amfi_copy_object_with_proc,
	},
};

__startup_func
static void
sweet_amfi_register(void)
{
	amfi_interface_register(&sweet_amfi);
	printf("SWEET AMFI: built-in interface registered (XML entitlements)\n");
}
STARTUP(EARLY_BOOT, STARTUP_RANK_MIDDLE, sweet_amfi_register);

/*
 * The signature reached this hook validated, so mark it CS_SIGNED like AMFI
 * does: exec copies the flag to the process, and csproc_get_blob() (csops
 * status, cdhash, platform and entitlement queries by process) ignores
 * processes without it. Every signed binary on the root filesystem is a
 * platform binary. New signatures (ubc_cs_blob_add passes its writable copy;
 * revalidation passes the read-only blob itself) get their entitlements here.
 */
static int
sweet_amfi_vnode_check_signature(struct vnode *vp, __unused struct label *label,
    __unused cpu_type_t cpu_type, struct cs_blob *cs_blob,
    unsigned int *cs_flags, __unused unsigned int *signer_type,
    __unused int flags, __unused unsigned int platform,
    __unused char **fatal_failure_desc, __unused size_t *fatal_failure_desc_len)
{
	mount_t mp = vnode_mount(vp);
	*cs_flags |= CS_SIGNED;
	if (mp != NULL && (vfs_flags(mp) & MNT_ROOTFS)) {
		*cs_flags |= CS_PLATFORM_BINARY;
	}
	/*
	 * SWEET (7195 port): this line's struct cs_blob has no csb_ro_addr, so
	 * the read-only-blob test from the 8796 line cannot be expressed. Only
	 * attach when the blob has no entitlements yet.
	 */
	if (cs_blob->csb_entitlements == NULL) {
		sweet_amfi_attach_entitlements(cs_blob);
	}
	return 0;
}

/*
 * Policy "Sandbox": libsystem_sandbox calls __mac_syscall("Sandbox", op,
 * arg). Without a policy of that name every call fails with ENOPOLICY and
 * launchd reports mach lookups as "error = 159: Sandbox restriction"
 * (backboardd cannot reach mobilegestalt or iohideventsystem; tccd:
 * "profile not found"). SWEET runs without a sandbox: operations succeed
 * (checks allow, profile init is accepted); the few that must return
 * data (container paths, extension tokens) fail with ENOENT. The first
 * use of each operation number is logged.
 */
static uint64_t sweet_sandbox_seen;


/*
 * SWEET (7195 port): Sandbox op 4, container path of a pid, from the
 * iOSPlus10 port (0223). PlugInKit's checkEnvironment aborts every app
 * extension with "plugin has invalid sandbox or container: error 2" when
 * this answers ENOENT, so no extension point (widgets, poster providers,
 * and the same path backboardd uses for its own sandboxed helper lookups)
 * ever comes up. App extensions that run as mobile (uid 501) get the mobile
 * home; everything else keeps ENOENT, like an uncontainerized process.
 *
 * arg is { int64 pid; 0; char *buffer; u64 buffer length; 0 }.
 */
static int
sweet_sandbox_container_path(user_addr_t arg)
{
	static const char home[] = "/private/var/mobile";
	uint64_t a[5];
	char path[MAXPATHLEN + 1];
	int len = sizeof(path), err = ENOENT;

	if (copyin(arg, a, sizeof(a)) != 0 || a[2] == 0 || a[3] < sizeof(home)) {
		return ENOENT;
	}
	proc_t target = proc_find((int)a[0]);
	if (target == NULL) {
		return ESRCH;
	}
	kauth_cred_t cred = kauth_cred_proc_ref(target);
	uid_t uid = kauth_cred_getuid(cred);
	kauth_cred_unref(&cred);
	vnode_t vp = proc_getexecutablevnode(target);
	proc_rele(target);
	if (vp == NULLVP) {
		return ENOENT;
	}
	if (uid == 501 && vn_getpath(vp, path, &len) == 0 &&
	    strnstr(path, ".appex/", sizeof(path)) != NULL) {
		err = copyout(home, (user_addr_t)a[2], sizeof(home));
	}
	vnode_put(vp);
	return err;
}


/*
 * SWEET (7195 port): Sandbox extension ops 5 (issue) and 6 (consume), from
 * the Bergamota 0116 patch. There is nothing to enforce here, but callers
 * need a token to hand around: tccd grants Photos/Contacts access and then
 * issues a sandbox extension for the service; when that failed with ENOENT
 * it answered "server error: Failed to issue Sandbox Extension"
 * (kTCCErrorDomain 6) even though access had been granted, and assetsd died
 * with "assetsd requires TCCPhotosService access". Our logs show op 5 from
 * amsaccountsd and op 7 from contextstored in every boot.
 */
#define SWEET_SBX_OP_EXT_ISSUE          5
#define SWEET_SBX_OP_EXT_CONSUME        6
#define SWEET_SBX_EXT_LOG_MAX           8

static uint64_t sweet_sandbox_ext_serial;
static int sweet_sandbox_ext_logged;

/*
 * libsystem_sandbox __sandbox_extension_issue passes seven 64-bit words:
 * [0] class or path (C string), [1] extension type, [2] target pid or audit
 * token (0 for self), [3] flags, [4] output buffer (0x800 bytes) for the
 * token string, [5] and [6] unused here.
 */
static int
sweet_sandbox_extension_issue(struct proc *p, user_addr_t arg)
{
	uint64_t a[7];
	int error = copyin(arg, a, sizeof(a));
	if (error != 0) {
		return error;
	}
	if (a[4] == 0) {
		return EINVAL;
	}
	char name[96] = "";
	size_t done = 0;
	if (a[0] != 0) {
		(void)copyinstr((user_addr_t)a[0], name, sizeof(name), &done);
		name[sizeof(name) - 1] = '\0';
	}
	uint64_t serial = ++sweet_sandbox_ext_serial;
	char token[160];
	snprintf(token, sizeof(token), "SWEET-%llu;%llu;%s",
	    (unsigned long long)serial, (unsigned long long)a[1], name);
	if (sweet_sandbox_ext_logged < SWEET_SBX_EXT_LOG_MAX) {
		sweet_sandbox_ext_logged++;
		char pname[32];
		proc_name(proc_pid(p), pname, sizeof(pname));
		printf("SWEET Sandbox: %s issued extension type %llu '%s'\n", pname,
		    (unsigned long long)a[1], name);
	}
	return copyout(token, (user_addr_t)a[4], strlen(token) + 1);
}

/* Consume: { token string, length incl. NUL, int64_t *handle }. */
static int
sweet_sandbox_extension_consume(user_addr_t arg)
{
	uint64_t a[3];
	int error = copyin(arg, a, sizeof(a));
	if (error != 0) {
		return error;
	}
	if (a[0] == 0 || a[2] == 0) {
		return EINVAL;
	}
	uint64_t handle = ++sweet_sandbox_ext_serial;
	return copyout(&handle, (user_addr_t)a[2], sizeof(handle));
}

static int
sweet_sandbox_syscall(struct proc *p, int call, user_addr_t arg)
{
	if (call >= 0 && call < 64 && !(sweet_sandbox_seen & (1ULL << call))) {
		sweet_sandbox_seen |= 1ULL << call;
		char name[32];
		proc_name(proc_pid(p), name, sizeof(name));
		printf("SWEET Sandbox: %s op %d\n", name, call);
	}
	switch (call) {
	case SWEET_SBX_OP_EXT_ISSUE:
		return sweet_sandbox_extension_issue(p, arg);
	case SWEET_SBX_OP_EXT_CONSUME:
		return sweet_sandbox_extension_consume(arg);
	case 4:         /* container path (pid) */
		return sweet_sandbox_container_path(arg);
	case 0x43:      /* container expected */
		return ENOENT;
	default:
		return 0;
	}
}

static const struct mac_policy_ops sweet_amfi_mac_ops = {
	.mpo_vnode_check_signature = sweet_amfi_vnode_check_signature,
};

/*
 * Privileges for non-root processes come from MAC policies (priv_check_cred
 * -> mac_priv_grant); on iOS Sandbox/AMFI grant them. Without a grant UIKit
 * apps die in CoreAnimation setup: work_interval_create(CA_CLIENT) needs
 * PRIV_WORK_INTERVAL ("Failed to create work interval", SpringBoard).
 * Grant that one; log the first denial of each other privilege per process.
 */
#define SWEET_PRIV_LOG_MAX      64
static struct {
	int  priv;
	char name[20];
} sweet_priv_logged[SWEET_PRIV_LOG_MAX];
static int sweet_priv_logged_count;

static int
sweet_sandbox_priv_grant(kauth_cred_t cred __unused, int priv)
{
	if (priv == PRIV_WORK_INTERVAL) {
		return 0;
	}
	/*
	 * SWEET (7195 port): three privileges the system's own code asks for and
	 * the real Sandbox grants, from the iOSPlus10 port (0222). Without them
	 * the daemons named beside each one take an error path:
	 *   1002 PRIV_GLOBAL_PROC_INFO  proc_info about other users' processes
	 *        (aggregated, cloudd). Granted to platform binaries.
	 *   1007 PRIV_DARKBOOT          writing kern.darkboot (SpringBoard).
	 *        Granted to platform binaries.
	 *   12000 PRIV_SKYWALK_REGISTER_USER_PIPE  (identityservicesd), granted
	 *        with com.apple.private.skywalk.register-user-pipe. The constant
	 *        has no name in this tree's priv.h, hence the literal.
	 * The check is only made when the credential asked about belongs to the
	 * current process, since that is the only case where "this process is a
	 * platform binary" is the right question.
	 */
	if (cred == kauth_cred_get()) {
		extern boolean_t csproc_get_platform_binary(proc_t);
		proc_t cp = current_proc();
		/*
		 * SWEET (7195 port): grant by entitlement, as the HackiOS port does
		 * (kern_minimac.c:268), and only fall back to "platform binary".
		 *
		 * The platform-binary test alone never fires here: the logs show 44
		 * `privilege 1002 denied` lines in a single boot (log33) and not one
		 * `granted` line in any log, including for backboardd,
		 * SpringBoard and tccd. Whatever breaks the CS_SIGNED ->
		 * csb_platform_binary propagation, the entitlement is the
		 * documented contract of the real Sandbox and does not depend on
		 * it. 1015 and 10003 are added because our logs show those denied
		 * too (mediaserverd, symptomsd) and no port of ours answered them.
		 */
		static const struct {
			int priv;
			const char *entitlement;
		} sweet_priv_ents[] = {
			{ PRIV_GLOBAL_PROC_INFO, "com.apple.private.kernel.global-proc-info" },
			{ PRIV_DARKBOOT, "com.apple.private.kernel.darkboot" },
			{ 1015, "com.apple.private.kernel.override-cpumon" },
			{ 10003, "com.apple.private.network.statistics" },
			{ 12000, "com.apple.private.skywalk.register-user-pipe" },
		};
		for (unsigned int i = 0;
		    i < sizeof(sweet_priv_ents) / sizeof(sweet_priv_ents[0]); i++) {
			if (sweet_priv_ents[i].priv == priv &&
			    sweet_entitlements_bool(sweet_proc_entitlements(cp),
			    sweet_priv_ents[i].entitlement)) {
				return 0;
			}
		}
		switch (priv) {
		case PRIV_GLOBAL_PROC_INFO:   /* 1002 */
		case PRIV_DARKBOOT:           /* 1007 */
			if (csproc_get_platform_binary(cp)) {
				static uint32_t granted;
				if (!(granted & (priv == PRIV_DARKBOOT ? 2u : 1u))) {
					granted |= priv == PRIV_DARKBOOT ? 2u : 1u;
					char n[20];
					proc_selfname(n, sizeof(n));
					printf("SWEET Sandbox: %s privilege %d granted\n", n, priv);
				}
				return 0;
			}
			break;
		default:
			break;
		}
	}
	char name[20];
	proc_selfname(name, sizeof(name));
	for (int i = 0; i < sweet_priv_logged_count; i++) {
		if (sweet_priv_logged[i].priv == priv &&
		    strncmp(sweet_priv_logged[i].name, name, sizeof(name)) == 0) {
			return EPERM;
		}
	}
	if (sweet_priv_logged_count < SWEET_PRIV_LOG_MAX) {
		sweet_priv_logged[sweet_priv_logged_count].priv = priv;
		strlcpy(sweet_priv_logged[sweet_priv_logged_count].name, name, sizeof(name));
		sweet_priv_logged_count++;
		printf("SWEET Sandbox: %s privilege %d denied\n", name, priv);
	}
	return EPERM;
}

static const struct mac_policy_ops sweet_sandbox_mac_ops = {
	.mpo_policy_syscall = sweet_sandbox_syscall,
	.mpo_priv_grant = sweet_sandbox_priv_grant,
};

static struct mac_policy_conf sweet_sandbox_mac_conf = {
	.mpc_name = "Sandbox",
	.mpc_fullname = "SWEET permissive sandbox stand-in",
	.mpc_ops = &sweet_sandbox_mac_ops,
};

static mac_policy_handle_t sweet_sandbox_mac_handle;

/*
 * Galaxy S9 (jailbreak userland): dyld asks AMFI, through
 * __mac_syscall("AMFI", 90, {in_flags, out_flags_ptr}), which DYLD_*
 * variables a process may use (amfi_check_dyld_policy_self). With no policy
 * of that name the call fails and dyld treats every process as restricted,
 * so ElleKit's DYLD_INSERT_LIBRARIES (SpringBoard tweaks) is ignored. Answer
 * it allowing everything, as jailbreaks do; other AMFI calls keep failing
 * with ENOPOLICY exactly as before.
 *
 * SWEET (7195 port): restored from the 8796 line -- the 7195 drop left
 * launchd dying in dyld's configureProcessRestrictions with
 * "amfi_check_dyld_policy_self() failed". Verified against the shipped
 * 18C66 dyld (usr/lib/dyld, _amfi_check_dyld_policy_self): it calls
 * ___sandbox_ms("AMFI", 0x5a, {u64 in_flags, u64 *out_flags_ptr}) and halts
 * on a non-zero return, and ___sandbox_ms aliases ___mac_syscall
 * (libsyscall/Platforms/syscall.map), so mpo_policy_syscall of the policy
 * named "AMFI" is the call that must return 0.
 */
#define SWEET_AMFI_DYLD_POLICY          90
#define SWEET_AMFI_DYLD_ALLOW_ALL       0xffULL /* every AMFI_DYLD_OUTPUT_* bit, incl. 0x20: a missing inserted library is not fatal */
/* amfi_interface_query_bootarg_state (0x60): bits lsd/installd check for
 * "extension catalog is trustworthy" and "enforcement disabled". */
#define SWEET_AMFI_BOOTARG_STATE        0x60
#define SWEET_AMFI_BOOTARG_STATE_VALUE  0x86ULL

static int
sweet_amfi_syscall(__unused struct proc *p, int call, user_addr_t arg)
{
	struct {
		uint64_t in_flags;
		uint64_t out_flags;     /* user pointer */
	} args;
	uint64_t allow = SWEET_AMFI_DYLD_ALLOW_ALL;
	static bool logged;

	if (!logged) {
		/* First __mac_syscall("AMFI", ...) of the boot: the dyld policy
		 * question. Reaches the persistent log through the panic flush. */
		logged = true;
		char name[32];
		proc_selfname(name, sizeof(name));
		printf("SWEET AMFI: dyld policy call %d from %s\n", call, name);
	}
	if (call == SWEET_AMFI_BOOTARG_STATE) {
		/*
		 * SWEET (7195 port): amfi_interface_query_bootarg_state, from the
		 * iOSPlus10 port (0221). ExtensionFoundation (lsd) verifies the
		 * signed extension-point catalog /System/Library/xpc/extensions.plist
		 * through AMFI unless (state & 0x86) != 0. With no AMFI policy the
		 * read fails, the catalog stays empty and NO app extension is ever
		 * registered -- which is what makes iOS run without widgets, poster
		 * providers and other extensions. Answering 0x86 also tells lsd and
		 * installd that code-signing enforcement is off, which is true here.
		 * arg is a single u64 out-pointer.
		 */
		uint64_t state = SWEET_AMFI_BOOTARG_STATE_VALUE;
		if (arg == 0) {
			return EFAULT;
		}
		return copyout(&state, arg, sizeof(state));
	}
	if (call != SWEET_AMFI_DYLD_POLICY) {
		return ENOPOLICY;
	}
	if (copyin(arg, &args, sizeof(args)) != 0 || args.out_flags == 0) {
		return EFAULT;
	}
	return copyout(&allow, (user_addr_t)args.out_flags, sizeof(allow));
}

static const struct mac_policy_ops sweet_amfi_syscall_mac_ops = {
	.mpo_policy_syscall = sweet_amfi_syscall,
};

static struct mac_policy_conf sweet_amfi_syscall_mac_conf = {
	.mpc_name = "AMFI",
	.mpc_fullname = "SWEET AMFI dyld policy",
	.mpc_ops = &sweet_amfi_syscall_mac_ops,
};

static mac_policy_handle_t sweet_amfi_syscall_mac_handle;

static struct mac_policy_conf sweet_amfi_mac_conf = {
	.mpc_name = "SWEET AMFI",
	.mpc_fullname = "SWEET built-in Mobile File Integrity",
	.mpc_ops = &sweet_amfi_mac_ops,
};

static mac_policy_handle_t sweet_amfi_mac_handle;

/* Called from bsd_init once MAC policies can register, before any exec. */
void sweet_amfi_policy_register(void);

void
sweet_amfi_policy_register(void)
{
	int error = mac_policy_register(&sweet_amfi_mac_conf, &sweet_amfi_mac_handle, NULL);
	printf("SWEET AMFI: platform binary policy %s (%d)\n",
	    error ? "NOT registered" : "registered", error);
	error = mac_policy_register(&sweet_amfi_syscall_mac_conf, &sweet_amfi_syscall_mac_handle, NULL);
	printf("SWEET AMFI: dyld policy (allow DYLD_INSERT_LIBRARIES) %s (%d)\n",
	    error ? "FAILED" : "registered", error);
	error = mac_policy_register(&sweet_sandbox_mac_conf, &sweet_sandbox_mac_handle, NULL);
	printf("SWEET Sandbox: permissive policy %s (%d)\n",
	    error ? "NOT registered" : "registered", error);
}
#endif /* ARM64_BOARD_CONFIG_SWEET */
