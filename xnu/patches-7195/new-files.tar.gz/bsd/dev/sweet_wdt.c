/*
 * SWEET (7195 port): the APSS watchdog, armed by the kernel.
 *
 * Why this exists
 * ---------------
 * The shim arms the watchdog (s9port/shim/plat.c, wdog_arm) and pets it while
 * it draws. Then it jumps to XNU, and m4.c says so in its own header:
 *
 *     "The APSS watchdog stays off: XNU does not feed it."
 *
 * So today a kernel hang is a dead phone: adb stops answering, nothing appears
 * on USB, and somebody has to hold Power + Volume Down. That is the exact
 * symptom recorded in PROMPT-SESSAO-2026-11-12.md 12, and it is what makes
 * every failed round cost a human.
 *
 * The Galaxy S5 port (Quantitative101/iOS7-KLTE-GalaxyS5, s5/stub/stub.c) does
 * the opposite: it arms the watchdog before entering the kernel and writes the
 * recovery restart reason first, so "a hang, a panic or the end of the kernel's
 * run window brings the phone back to TWRP without anyone pressing buttons".
 * This file is that pattern, for this SoC.
 *
 * What it does
 * ------------
 *   sweet_wdt_arm(seconds)  program BARK/BITE and enable, once.
 *   sweet_wdt_pet()         write RST; called from the timer interrupt.
 *   sweet_wdt_disarm()      turn it off (used when we reset on purpose).
 *
 * The pet lives in rtclock_intr (osfmk/arm/rtclock.c), which runs on every
 * timer tick on every CPU. A hang that stops the tick stops the petting, and
 * the hardware resets the SoC. The BCB (sweet_bcb.c) is written before any
 * deliberate reset, so the bootloader comes back to TWRP.
 *
 * Register layout and clock are the same ones the shim uses and the same ones
 * drivers/soc/qcom/watchdog_v2.c uses: qcom,wdt@17980000, 32765 Hz sleep clock,
 * RST +0x04, EN +0x08, BARK_TIME +0x10, BITE_TIME +0x14.
 *
 * The window is deliberately long. A normal boot reaches the userland in about
 * three seconds, but a slow one (HFS repair, a soak test) must not be killed by
 * the watchdog itself; 90 s is far past anything healthy and far short of a
 * human's patience.
 */
#include <mach/mach_types.h>
#include <kern/kern_types.h>
#include <kern/assert.h>
#include <kern/clock.h>
#include <pexpert/pexpert.h>
#include <vm/vm_kern.h>
#include <vm/vm_map.h>
#include <arm64/sweet_early.h>

#if defined(ARM64_BOARD_CONFIG_SWEET)

#define SWEET_WDT_PA        0x17980000UL
#define SWEET_WDT_RST       0x04
#define SWEET_WDT_EN        0x08
#define SWEET_WDT_BARK      0x10
#define SWEET_WDT_BITE      0x14
#define SWEET_WDT_HZ        32765UL
#define SWEET_WDT_DEFAULT_S 90

extern vm_offset_t ml_io_map(vm_offset_t, vm_size_t);
extern int printf(const char *, ...) __printflike(1, 2);

void sweet_wdt_arm(void);
void sweet_wdt_pet(void);
void sweet_wdt_disarm(void);

static volatile uint32_t *sweet_wdt_regs;
static uint32_t sweet_wdt_seconds;

static inline void
sweet_wdt_wr(uint32_t off, uint32_t val)
{
	if (sweet_wdt_regs != NULL) {
		sweet_wdt_regs[off / 4] = val;
	}
}

/*
 * Arm once. Safe to call more than once: the second call only pets.
 * Boot-arg sweetwdt=<seconds> overrides the window; sweetwdt=0 disables.
 */
void
sweet_wdt_arm(void)
{
	uint32_t secs = SWEET_WDT_DEFAULT_S;

	if (sweet_wdt_regs != NULL) {
		sweet_wdt_pet();
		return;
	}
	if (PE_parse_boot_argn("sweetwdt", &secs, sizeof(secs))) {
		if (secs == 0) {
			printf("SWEET WDT: disabled by boot-arg\n");
			return;
		}
	}
	if (secs < 10) {
		secs = 10;
	}
	sweet_wdt_regs = (volatile uint32_t *)ml_io_map(SWEET_WDT_PA, 0x1000);
	if (sweet_wdt_regs == NULL) {
		printf("SWEET WDT: ml_io_map failed, watchdog stays off\n");
		return;
	}
	sweet_wdt_seconds = secs;
	sweet_wdt_wr(SWEET_WDT_EN, 0);
	sweet_wdt_wr(SWEET_WDT_BARK, secs * SWEET_WDT_HZ);
	sweet_wdt_wr(SWEET_WDT_BITE, (secs + 5) * SWEET_WDT_HZ);
	sweet_wdt_wr(SWEET_WDT_EN, 1);
	sweet_wdt_pet();
	printf("SWEET WDT: armed, bark %us bite %us\n", secs, secs + 5);
}

/* Called from the timer interrupt on every CPU. Must not block or allocate. */
void
sweet_wdt_pet(void)
{
	sweet_wdt_wr(SWEET_WDT_RST, 1);
}

void
sweet_wdt_disarm(void)
{
	sweet_wdt_wr(SWEET_WDT_EN, 0);
}

#else /* !ARM64_BOARD_CONFIG_SWEET */

void sweet_wdt_arm(void) { }
void sweet_wdt_pet(void) { }
void sweet_wdt_disarm(void) { }

#endif /* ARM64_BOARD_CONFIG_SWEET */
