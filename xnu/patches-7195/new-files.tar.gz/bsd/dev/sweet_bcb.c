/*
 * SWEET (7195 port): Android boot command block (BCB) — the recovery cookie.
 *
 * Why this exists
 * ---------------
 * Every kernel round costs a human: the phone has to be put into TWRP by hand
 * before the next image can be pushed. The OnePlus 2 port solved this with the
 * same trick Android itself uses: the bootloader reads a 512-byte block at the
 * start of the `misc` partition on every boot, and if it says "boot-recovery"
 * it goes to recovery instead of the normal system.
 *
 * So the kernel writes that block before it resets, and the next boot lands in
 * TWRP with nobody touching the phone. That is the entire mechanism — it does
 * not touch the partition table, and nothing is written anywhere except that
 * one block inside `misc`.
 *
 * Geometry, measured on this device (Galaxy S9, GPT, TWRP numbering)
 * -----------------------------------------------------------------
 * The GPT lives at LBA 1 of 512-byte sectors, not LBA 0: sector 0 is a
 * protective MBR (its type-0xEE entry is what made an earlier session conclude
 * the disk was MBR). Reading it gives the entries in order, and matching them
 * against /sys/class/block/sdaN/start identifies which sdaN is which:
 *
 *     misc      first sector 17163  -> device block 2145 (4096-byte blocks)
 *     boot      first sector 93707  -> sda20   (our flash.sh target)
 *     recovery  first sector 110091 -> sda21
 *
 * The device block is what the driver speaks: WRITE(10) takes 4096-byte block
 * addresses. 17163 * 512 / 4096 = 2145.375, so the BCB is not block-aligned;
 * writing block 2145 writes sectors 17160..17167 and the block's first 1536
 * bytes are sectors 17160..17162 (the tail of `ssd`/`persist`, which belong to
 * neither partition). Android's own recovery does exactly this, so a whole
 * block write is the correct behaviour, not a widened blast radius.
 *
 * Format (bootloader_message, as in AOSP's bootloader_message.h)
 * --------------------------------------------------------------
 *   0x000  char command[32]     "boot-recovery\0"
 *   0x020  char status[32]      unused here
 *   0x040  char recovery[768]   "--prompt_and_wipe_data" style args, unused
 *   0x340  char stage[32]
 *   0x360  char reserved[1184]
 * Only `command` is read to decide recovery; the rest stays zero.
 *
 * Safety
 * ------
 *   - one fixed LBA, one 4096-byte block, validated by sweet_ufs_write_abs();
 *   - the write happens from the panic path, before the reset;
 *   - boot-arg `sweetbcb=0` disables it entirely;
 *   - if the write fails the reset still happens, so a broken BCB never
 *     strands the phone in the kernel.
 */
#include <sys/param.h>
#include <sys/systm.h>
#include <sys/mount.h>
#include <sys/proc.h>
#include <kern/kern_types.h>
#include <kern/debug.h>
#include <pexpert/pexpert.h>

#if defined(ARM64_BOARD_CONFIG_SWEET)

/* 17163 sectors * 512 = 8787456 bytes; the block that CONTAINS it is 2145,
 * at 8785920. The BCB therefore starts 1536 bytes into that block, and the
 * bytes before it belong to the tail of `param` (verified by dumping the
 * block: it holds live data). Hence the read-modify-write. */
#define SWEET_MISC_BCB_BLOCK    2145ull
#define SWEET_MISC_BCB_OFFSET   1536u
#define SWEET_BCB_CMD_OFF       0u
#define SWEET_BCB_CMD_LEN       32u

extern int sweet_ufs_write_abs_rmw(uint64_t lba, uint32_t offset_in_block,
    const void *src, uint32_t len);

static TUNABLE(uint32_t, sweetbcb, "sweetbcb", 1);

/*
 * Write "boot-recovery" into misc so the bootloader enters TWRP next time.
 * Safe to call from the panic path: no allocation, no locks, one
 * read-modify-write of a fixed block.
 */
void
sweet_bcb_request_recovery(void)
{
	static const char cmd[SWEET_BCB_CMD_LEN] = "boot-recovery";
	int error;

	if (!sweetbcb) {
		return;
	}

	error = sweet_ufs_write_abs_rmw(SWEET_MISC_BCB_BLOCK,
	    SWEET_MISC_BCB_OFFSET + SWEET_BCB_CMD_OFF, cmd, sizeof(cmd));
	printf("SWEET BCB: boot-recovery into misc (block %llu +%u) -> %d\n",
	    (unsigned long long)SWEET_MISC_BCB_BLOCK, SWEET_MISC_BCB_OFFSET, error);
}

/*
 * Clear it again, for the case where a normal boot should stay normal.
 * Kept for boot scripts; nothing calls it automatically today.
 */
void
sweet_bcb_clear(void)
{
	static const char zero[SWEET_BCB_CMD_LEN] = { 0 };

	(void)sweet_ufs_write_abs_rmw(SWEET_MISC_BCB_BLOCK,
	    SWEET_MISC_BCB_OFFSET + SWEET_BCB_CMD_OFF, zero, sizeof(zero));
}

/*
 * Leave the kernel and come back in TWRP.
 *
 * PSCI SYSTEM_RESET (0x84000009) is the clean way, and it is what the shim's
 * reboot() uses. On this Samsung firmware the Secure Monitor owns reset and
 * may refuse the PSCI contract, in which case the SMC returns an error and we
 * would spin forever — exactly the hang seen on 2026-11-12. So: try PSCI,
 * and if it comes back, arm the APSS watchdog and stop petting it. The
 * hardware then resets the SoC a few seconds later, which the bootloader
 * turns into a normal boot into recovery because the BCB is already written.
 *
 * __dead2: nothing after this runs on the PSCI-success path.
 */
void
sweet_reset_into_recovery(void)
{
	register uint64_t x0 __asm__("x0") = 0x84000009ULL;	/* PSCI SYSTEM_RESET */

	__asm__ volatile("smc #0" : "+r"(x0) : :
	    "x1", "x2", "x3", "x4", "x5", "x6", "x7",
	    "x8", "x9", "x10", "x11", "x12", "x13", "x14", "x15",
	    "x16", "x17", "cc", "memory");

	/*
	 * PSCI refused (or returned): fall back to hardware. Registers and
	 * clock match the shim's plat.c (qcom,wdt@17980000, 32765 Hz).
	 */
	{
#define SWEET_APSS_WDT      0x17980000UL
#define SWEET_WDT0_EN       0x08
#define SWEET_WDT0_BARK     0x10
#define SWEET_WDT0_BITE     0x14
#define SWEET_WDT_HZ        32765UL
		*(volatile uint32_t *)(SWEET_APSS_WDT + SWEET_WDT0_EN) = 0;
		*(volatile uint32_t *)(SWEET_APSS_WDT + SWEET_WDT0_BARK) = 15 * SWEET_WDT_HZ;
		*(volatile uint32_t *)(SWEET_APSS_WDT + SWEET_WDT0_BITE) = 18 * SWEET_WDT_HZ;
		*(volatile uint32_t *)(SWEET_APSS_WDT + SWEET_WDT0_EN) = 1;
#undef SWEET_APSS_WDT
#undef SWEET_WDT0_EN
#undef SWEET_WDT0_BARK
#undef SWEET_WDT0_BITE
#undef SWEET_WDT_HZ
	}
	for (;;) {
		__asm__ volatile("wfe");	/* the watchdog bites */
	}
}

#endif /* ARM64_BOARD_CONFIG_SWEET */
