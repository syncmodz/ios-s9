/*
 * SWEET: force the NFS client half on, after meta_features.h has had its say.
 *
 * meta_features.h is pulled in with -include and pulls in nfsclient.h, which
 * this tree generates as "#define NFSCLIENT 0". Anything -D sets is overridden
 * by that (forced includes are processed after the command-line defines), so
 * nfs_conf.h leaves CONFIG_NFS_CLIENT undefined and the client half of
 * nfs_subs.c -- where nfs_debug_ctl, nfs_printf, nfs_dump_mbuf and the xb_*
 * helpers live -- is compiled out. nfs_vfsops.c is worse: its whole body sits
 * under #if CONFIG_NFS_CLIENT, so the object came out with one symbol and
 * nfs_mountroot was never defined.
 *
 * This header is force-included after meta_features.h, so its value wins.
 */
#ifndef SWEET_NFS_CLIENT_H
#define SWEET_NFS_CLIENT_H

#undef NFSCLIENT
#define NFSCLIENT 1

#undef NFSSERVER
#define NFSSERVER 1

/*
 * nfs_socket.c keeps nfs_request_gss() under #if CONFIG_NFS_GSS, and
 * nfs_gss.c calls it from the client context paths. config/MASTER declares
 * the option as CONFIG_NFS_GSS but the generated meta header exports it as
 * NCONFIG_NFS_GSS, which never matches this guard.
 */
#undef CONFIG_NFS_GSS
#define CONFIG_NFS_GSS 1

#endif /* SWEET_NFS_CLIENT_H */
