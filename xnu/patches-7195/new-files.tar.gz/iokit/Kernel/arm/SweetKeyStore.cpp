/*
 * Built-in AppleKeyStore for SWEET: a device without a passcode whose
 * system keybag is always loaded and unlocked.
 *
 * Apple's AppleKeyStore kext (closed, SEP-backed) owns the keybags behind
 * data protection. libaks (AppleKeyStore.framework, statically in keybagd)
 * opens IOServiceMatching("AppleKeyStore") with type 0, calls selector 0,
 * then one selector per aks_* function (iOS 16.7 numbering below). keybagd
 * --init asks for the system bag (14) and only loads systembag.kb when the
 * answer is kIOReturnNotFound; answering with a handle is the path a
 * userspace reboot takes, so no bag file is needed.
 *
 * Every call is logged (selector, caller, argument shapes, result) so the
 * next selectors the system needs show up on the console; unknown ones fail
 * with kIOReturnUnsupported.
 */
#include <pexpert/arm64/board_config.h>

#if defined(SWEET)
#include <IOKit/IOService.h>
#include <IOKit/IOUserClient.h>
#include <IOKit/IOKitKeys.h>
#include <IOKit/IOLib.h>
#include <IOKit/IOMemoryDescriptor.h>
#include <libkern/c++/OSString.h>
#include <sys/proc.h>

/* libaks selectors (AppleKeyStore.framework, iOS 16.7). */
enum {
	kAKSOpen             = 0,
	kAKSCreateBag        = 2,
	kAKSSaveBag          = 3,
	kAKSUnloadBag        = 4,
	kAKSSetSystem        = 5,
	kAKSLoadBag          = 6,
	kAKSGetLockState     = 7,
	kAKSUnlockDevice     = 9,
	kAKSWrapKey          = 10,
	kAKSUnwrapKey        = 11,
	kAKSLockDevice       = 8,       /* aks_lock_device(handle, now = false) */
	kAKSLockDeviceNow    = 32,      /* aks_lock_device(handle, now = true) */
	kAKSUnlockBag        = 12,
	kAKSLockBag          = 13,
	kAKSGetSystem        = 14,
	kAKSGetDeviceState   = 17,
	kAKSGetExtDeviceState = 35,     /* aks_get_extended_device_state */
	kAKSAssertHold       = 26,
	kAKSAssertDrop       = 27,
	kAKSUnloadSessionBags = 55,
	kAKSNotifyStateSet   = 102,
	kAKSNotifyStateIsSet = 103,
	kAKSAssertConsume    = 101,     /* aks_assert_consume */
	/*
	 * SWEET: selectors the 2026-10 Bergamota boot saw refused with
	 * 0xe00002c7 (keybagd 107, securityd 10, profiled 31). Answering them on
	 * the unlocked/no-passcode path costs nothing and removes three crash
	 * paths that otherwise look like keybag breakage.
	 */
	kAKSProfileState       = 31,    /* profiled */
	kAKSKeybagStateQuery   = 107,   /* keybagd */
};

/* The system (device) bag handle. */
#define SWEET_AKS_SYSTEM_HANDLE 0

/* aks_wrap_key output tag; 8796 SweetKeyStore.cpp:68. */
#define SWEET_AKS_MAX_KEY       1024
static const uint8_t sweet_aks_wrap_tag[8] = { 'S', '9', 'A', 'K', 'S', 'W', '0', '1' };

/* defined below, next to the other structure helpers */
static IOReturn sweet_aks_struct_out(IOExternalMethodArguments *args, const void *buf, uint32_t len);

/*
 * Structure input (inband or descriptor) into buf; its length, or -1 if it
 * does not fit. Transcribed from the 8796 line (SweetKeyStore.cpp:184).
 */
static int32_t
sweet_aks_struct_in(IOExternalMethodArguments *args, uint8_t *buf, uint32_t max)
{
	if (args->structureInputDescriptor != NULL) {
		uint32_t len = (uint32_t)args->structureInputDescriptor->getLength();
		if (len > max) {
			return -1;
		}
		args->structureInputDescriptor->readBytes(0, buf, len);
		return (int32_t)len;
	}
	if (args->structureInputSize > max) {
		return -1;
	}
	if (args->structureInputSize > 0) {
		memcpy(buf, args->structureInput, args->structureInputSize);
	}
	return (int32_t)args->structureInputSize;
}

/*
 * aks_wrap_key: scalars [handle, class], key in; class out, tag + key out.
 * There is no SEP to wrap to, so this is a copy -- it is NOT protected at
 * rest, exactly as the 8796 line documents. Answering Unsupported instead
 * (what this did) sends securityd into a retry loop: the 8796 boot shows
 * 290087 calls to selector 10.
 */
static IOReturn
sweet_aks_wrap(IOExternalMethodArguments *args)
{
	uint8_t buf[sizeof(sweet_aks_wrap_tag) + SWEET_AKS_MAX_KEY];
	int32_t len = sweet_aks_struct_in(args, buf + sizeof(sweet_aks_wrap_tag), SWEET_AKS_MAX_KEY);
	if (len <= 0 || args->scalarInputCount < 2 || args->scalarOutputCount < 1) {
		return kIOReturnBadArgument;
	}
	memcpy(buf, sweet_aks_wrap_tag, sizeof(sweet_aks_wrap_tag));
	IOReturn ret = sweet_aks_struct_out(args, buf, sizeof(sweet_aks_wrap_tag) + (uint32_t)len);
	if (ret == kIOReturnSuccess) {
		args->scalarOutput[0] = args->scalarInput[1];
		args->scalarOutputCount = 1;
	}
	bzero(buf, sizeof(buf));
	return ret;
}

/* aks_unwrap_key: scalars [handle, class], tag + key in; key out. */
static IOReturn
sweet_aks_unwrap(IOExternalMethodArguments *args)
{
	uint8_t buf[sizeof(sweet_aks_wrap_tag) + SWEET_AKS_MAX_KEY];
	int32_t len = sweet_aks_struct_in(args, buf, sizeof(buf));
	args->scalarOutputCount = 0;
	if (len <= (int32_t)sizeof(sweet_aks_wrap_tag) ||
	    memcmp(buf, sweet_aks_wrap_tag, sizeof(sweet_aks_wrap_tag)) != 0) {
		return kIOReturnBadArgument;
	}
	IOReturn ret = sweet_aks_struct_out(args, buf + sizeof(sweet_aks_wrap_tag),
	    (uint32_t)len - sizeof(sweet_aks_wrap_tag));
	bzero(buf, sizeof(buf));
	return ret;
}


/*
 * aks lock state bits (aks_get_lock_state): bit 1 is "no passcode set",
 * bit 2 is "unlocked since boot" (MobileKeyBag MKBDeviceUnlockedSinceBoot).
 *
 * 0x4 alone means "there IS a passcode and it is unlocked", which is false on
 * this device and is a different path for MKBGetDeviceLockState. The
 * ios-sailfish 0180 and iOSPlus10 0220 patches both moved to 0x6 for exactly
 * this reason (sailfish: "coreduetd asked for the device state thousands of
 * times a minute" with 0x4), and neither went back.
 */
#define SWEET_AKS_LOCK_STATE    0x6

class AppleKeyStore : public IOService {
	OSDeclareDefaultStructors(AppleKeyStore);

public:
	bool start(IOService *provider) APPLE_KEXT_OVERRIDE;
};

OSDefineMetaClassAndStructors(AppleKeyStore, IOService);

bool
AppleKeyStore::start(IOService *provider)
{
	if (!IOService::start(provider)) {
		return false;
	}
	setProperty(kIOUserClientClassKey, "AppleKeyStoreUserClient");
	registerService();
	IOLog("SWEET AKS: AppleKeyStore registered (no passcode, unlocked)\n");
	return true;
}

class AppleKeyStoreUserClient : public IOUserClient {
	OSDeclareDefaultStructors(AppleKeyStoreUserClient);

public:
	IOReturn clientClose(void) APPLE_KEXT_OVERRIDE;
	IOReturn externalMethod(uint32_t selector, IOExternalMethodArguments *args,
	    IOExternalMethodDispatch *dispatch, OSObject *target,
	    void *reference) APPLE_KEXT_OVERRIDE;
};

OSDefineMetaClassAndStructors(AppleKeyStoreUserClient, IOUserClient);

IOReturn
AppleKeyStoreUserClient::clientClose(void)
{
	terminate();
	return kIOReturnSuccess;
}

/* Copy len bytes to the caller's output structure (inband or descriptor). */
static IOReturn
sweet_aks_struct_out(IOExternalMethodArguments *args, const void *buf, uint32_t len)
{
	if (args->structureOutputDescriptor != NULL) {
		if (len > args->structureOutputDescriptor->getLength()) {
			return kIOReturnNoSpace;
		}
		args->structureOutputDescriptor->writeBytes(0, buf, len);
		args->structureOutputDescriptorSize = len;
		return kIOReturnSuccess;
	}
	if (args->structureOutput == NULL || len > args->structureOutputSize) {
		return kIOReturnNoSpace;
	}
	memcpy(args->structureOutput, buf, len);
	args->structureOutputSize = len;
	return kIOReturnSuccess;
}

/* Append SEQUENCE { UTF8String key, INTEGER value } (short forms only). */
static uint32_t
sweet_aks_der_pair(uint8_t *p, const char *key, uint8_t value)
{
	uint32_t klen = (uint32_t)strlen(key);
	uint32_t n = 0;
	p[n++] = 0x30;
	p[n++] = (uint8_t)(2 + klen + 3);
	p[n++] = 0x0c;
	p[n++] = (uint8_t)klen;
	memcpy(p + n, key, klen);
	n += klen;
	p[n++] = 0x02;
	p[n++] = 0x01;
	p[n++] = value;
	return n;
}

/*
 * Device state (selector 17): a DER SET of key/INTEGER pairs that libaks
 * decode_extended_state reads: ss state, sls lock state (MKBGetDeviceLockState:
 * 0 = unlocked), sb backoff, sfa failed attempts, sgs generation, sas
 * assertions, sgpe grace period, srcd recovery countdown.
 */
static IOReturn
sweet_aks_device_state(IOExternalMethodArguments *args)
{
	static const struct {
		const char *key;
		uint8_t value;
	} fields[] = {
		/* sls 3 = "no passcode"; 0 reads as "passcode set, unlocked". */
		{ "ss", SWEET_AKS_LOCK_STATE }, { "sls", 3 }, { "sb", 0 }, { "sfa", 0 },
		{ "sgs", 0 }, { "sas", 0 }, { "sgpe", 0 }, { "srcd", 0 },
	};
	uint8_t buf[128];
	uint32_t n = 2;
	for (unsigned int i = 0; i < sizeof(fields) / sizeof(fields[0]); i++) {
		n += sweet_aks_der_pair(buf + n, fields[i].key, fields[i].value);
	}
	buf[0] = 0x31;
	buf[1] = (uint8_t)(n - 2);
	return sweet_aks_struct_out(args, buf, n);
}

static uint32_t
sweet_aks_struct_out_size(IOExternalMethodArguments *args)
{
	return args->structureOutputDescriptor != NULL ?
	       (uint32_t)args->structureOutputDescriptor->getLength() : args->structureOutputSize;
}

IOReturn
AppleKeyStoreUserClient::externalMethod(uint32_t selector, IOExternalMethodArguments *args,
    __unused IOExternalMethodDispatch *dispatch, __unused OSObject *target,
    __unused void *reference)
{
	IOReturn ret = kIOReturnSuccess;
	uint32_t in_scalars = args->scalarInputCount;
	uint32_t in_struct = args->structureInputDescriptor != NULL ?
	    (uint32_t)args->structureInputDescriptor->getLength() : args->structureInputSize;
	uint32_t out_scalars = args->scalarOutputCount;
	uint32_t out_struct = sweet_aks_struct_out_size(args);
	uint64_t arg0 = in_scalars > 0 ? args->scalarInput[0] : 0;

	switch (selector) {
	case kAKSOpen:
	case kAKSUnloadBag:
	case kAKSSetSystem:
	case kAKSUnlockDevice:
	case kAKSLockDevice:            /* no passcode: locking is a no-op */
	case kAKSLockDeviceNow:
	case kAKSUnlockBag:
	case kAKSLockBag:
	case kAKSAssertHold:
	case kAKSAssertDrop:
	case kAKSAssertConsume:
	case kAKSUnloadSessionBags:
	case kAKSNotifyStateSet:
		args->scalarOutputCount = 0;
		break;
	case kAKSGetSystem:
		if (out_scalars < 1) {
			ret = kIOReturnBadArgument;
			break;
		}
		/*
		 * SWEET (7195 port): answer with a handle, ALWAYS. This is the
		 * userspace-reboot path, and on this device it is the path that
		 * works.
		 *
		 * A previous revision answered kIOReturnNotFound to the first
		 * caller, on the theory (Bergamota patch 0038) that libaks only
		 * runs MKB_INIT when the answer is NotFound. The logs refute that
		 * for 18C66: the boot task (keybagd pid 11) gets a HANDLE and
		 * still runs the whole of MKB_INIT --
		 *
		 *   log33:202  SWEET AKS: keybagd sel 0  -> 0x0
		 *   log33:203  SWEET AKS: keybagd sel 14 -> 0x0   (handle)
		 *   log33:207  MKB_INIT: System Keybag loaded
		 *   log33:210  MKB_INIT: STARTING EARLYBOOT SETUP
		 *   log33:238  PALLOC ... id=1000 / 99 / 199  (personas created)
		 *   log33:243  MKB_INIT: setup kernel personas
		 *   log33:244  MKB_INIT: DONE EARLYBOOT SETUP
		 *
		 * -- and the same in log29..log32. So the premise was wrong: the
		 * personas are created, and the daemon instance (pid 38) is not
		 * stuck before MKB_INIT for this reason.
		 *
		 * Worse, NotFound is actively harmful here. keybagd's
		 * load_devicebag (0x10002f1f8) compares the result against
		 * 0xe00002f0 and, on a match, reads
		 * /private/var/keybags/systembag.kb; that file does not exist in
		 * this rootfs, and the failure is fatal ("failed to load system
		 * bag" -> kb_load -> reboot). The first GetSystem of the boot is
		 * the boot task's, so NotFound would break the one path that
		 * demonstrably completes.
		 */
		args->scalarOutput[0] = SWEET_AKS_SYSTEM_HANDLE;
		args->scalarOutputCount = 1;
		break;
	case kAKSGetLockState:
		if (out_scalars < 1) {
			ret = kIOReturnBadArgument;
			break;
		}
		args->scalarOutput[0] = SWEET_AKS_LOCK_STATE;
		args->scalarOutputCount = 1;
		break;
	case kAKSNotifyStateIsSet:
		/* Nothing was ever set: answer "not set". */
		if (out_scalars < 1) {
			ret = kIOReturnBadArgument;
			break;
		}
		args->scalarOutput[0] = 0;
		args->scalarOutputCount = 1;
		break;
	case kAKSGetDeviceState:
	case kAKSGetExtDeviceState:
		args->scalarOutputCount = 0;
		ret = sweet_aks_device_state(args);
		break;
	case kAKSProfileState:          /* profiled: nothing is enforced */
	case kAKSKeybagStateQuery:      /* keybagd: bag state is "locked out / none" */
		args->scalarOutputCount = 1;
		args->scalarOutput[0] = 0;
		ret = kIOReturnSuccess;
		break;
	case kAKSWrapKey:
		ret = sweet_aks_wrap(args);
		break;
	case kAKSUnwrapKey:
		ret = sweet_aks_unwrap(args);
		break;
	default:
		ret = kIOReturnUnsupported;
		break;
	}

	char name[32];
	proc_selfname(name, sizeof(name));
	IOLog("SWEET AKS: %s sel %u arg0 %llu in %u/%u out %u/%u -> 0x%x\n", name, selector,
	    arg0, in_scalars, in_struct, out_scalars, out_struct, ret);
	return ret;
}
#endif /* SWEET */
