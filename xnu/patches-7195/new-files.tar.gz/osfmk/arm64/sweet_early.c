/*
 * Redmi Note 10 Pro bootstrap console. No allocation, locks, ADT parsing or
 * per-CPU state: panic() can reach this before a current thread exists.
 * start.s maps the splash framebuffer VA=PA as Normal Non-Cacheable memory.
 * arm_vm_init installs a reserved kernel VA alias before removing TTBR0;
 * retain this console until the normal framebuffer serial console is ready.
 */
#include <arm64/sweet_early.h>

#if defined(SWEET)
#include <stdint.h>
#include <kern/misc_protos.h>

/*
 * SWEET (7195 port): Galaxy S9 geometry, taken from the 8796 line. This file
 * was the Redmi Note 10 Pro's (0x9c000000, 1080x2400, stride 4320), so on the
 * S9 every row landed in the wrong place and the early console drew nothing
 * visible. Splash is at 0x9d400000, 20MB into the 32MB block that start.s and
 * arm_vm_init map. Only rows below the block end (0x9e000000) are mapped:
 * (0x9e000000 - 0x9d400000) / 5760 = 2184.
 */
static volatile uint32_t *early_fb = (volatile uint32_t *)(uintptr_t)0x9d400000;
#define EARLY_FB early_fb
#define EARLY_WIDTH 1440u
#define EARLY_HEIGHT 2184u
#define EARLY_STRIDE (5760u / 4)
#define EARLY_SCALE 2u
#define EARLY_CELL_W (8u * EARLY_SCALE)
#define EARLY_CELL_H (16u * EARLY_SCALE)

/*
 * SWEET (7195 port): background artwork + text over the whole screen.
 *
 * The apple and the progress bar are static artwork. They are painted once,
 * and every console row that scrolls past them carries them as its own
 * background: clearing a row repaints black *or* the artwork pixels that
 * belong to it, then the glyphs go on top. Three results follow directly:
 *
 *   - the log uses the entire framebuffer height, not a band above the art
 *   - text passes over the apple instead of pushing it down
 *   - the artwork never flickers, because it is part of every row's clear
 *
 * Clearing one row costs at most 1440*32 = 46 K writes; rows that miss the
 * artwork take a plain fill. That is ~1 ms/line, versus the 2.6 M uncached
 * words (~50 ms/line) the old full-screen scroll cost.
 *
 * EARLY_HEIGHT (2184) is the mapped part of the 32 MiB splash block, not the
 * 2960-px panel: the rest of the framebuffer is outside the mapped window.
 */
#define LOGO_H_PX 241u
#define BAR_H_PX 8u

/* Text spans the framebuffer height; the status bar keeps the last 32 px. */
#define EARLY_ROWS ((EARLY_HEIGHT - 32u) / EARLY_CELL_H)   /* 67 rows */
#define EARLY_COLS (EARLY_WIDTH / EARLY_CELL_W)

/* Status bar at the very bottom of the framebuffer; never scrolled. */
#define EARLY_BAR_TOP (EARLY_HEIGHT - 32u)

/*
 * Artwork placement. The apple sits where it looked right on the device; the
 * progress bar lives inside the status strip at the very bottom, which text
 * never touches -- it sat under the text before and got buried by it.
 */
#define LOGO_X ((EARLY_WIDTH - 207u) / 2u)
#define LOGO_Y 1317u
#define BAR_Y (EARLY_BAR_TOP + 12u)
#define BAR_W 360u
#define BAR_X ((EARLY_WIDTH - BAR_W) / 2u)
/*
 * SWEET (7195 port): the apple is the rainbow artwork now, so it is drawn in
 * its own colours instead of a single grey watermark. Text still crosses it
 * (see sweet_early_clear_row), and the six bands are bright enough that the
 * white glyphs stay readable on top of them -- the old all-white apple was
 * the case that forced a mid-grey.
 *
 * logo_palette[] comes from sweet_logo.h (mklogo_color.py): index 0 is the
 * background, 1..6 are the bands. It holds plain 0xRRGGBB, so it needs the
 * opaque alpha this framebuffer wants or-ed in -- without it the whole apple
 * would be drawn at alpha 0, which on this scanout is black.
 */
#define LOGO_OPAQUE 0xff000000u
#define LOGO_RGB(idx) (logo_palette[idx] | LOGO_OPAQUE)
#define LOGO_BLACK 0xff000000u
#define BAR_TRACK 0xff303030u
#define BAR_FILL  0xffffffffu

extern unsigned char iso_font[256 * 16];

/* Initialized data must remain writable until disable, including panics. */
static unsigned int early_row, early_col;
static unsigned int early_started, early_disabled, early_panicking;

/* How much of the progress track is lit; set by sweet_early_mark. */
static unsigned int sweet_bar_fill_static;

/*
 * Artwork layer: painted once at startup, then never written wholesale. The
 * per-row clear keeps it alive under the text (see sweet_art_pixel).
 */
#include <arm64/sweet_logo.h>

static void
sweet_early_paint_logo(void)
{
	for (unsigned int y = 0; y < LOGO_H; y++) {
		unsigned int fy = LOGO_Y + y;
		if (fy >= EARLY_BAR_TOP) {
			break;
		}
		volatile uint32_t *line = EARLY_FB + fy * EARLY_STRIDE;
		for (unsigned int x = 0; x < LOGO_W; x++) {
			unsigned int fx = LOGO_X + x;
			if (fx >= EARLY_WIDTH) {
				break;
			}
			line[fx] = LOGO_RGB(logo_pixel((int)x, (int)y));
		}
	}
	/* Empty the progress bar's track so its first frame looks right. */
	for (unsigned int y = BAR_Y; y < BAR_Y + BAR_H_PX; y++) {
		volatile uint32_t *line = EARLY_FB + y * EARLY_STRIDE;
		for (unsigned int x = BAR_X; x < BAR_X + BAR_W; x++) {
			line[x] = BAR_TRACK;
		}
	}
	__asm__ volatile("dsb sy" ::: "memory");
}

/*
 * Artwork pixel lookup. Returns TRUE and writes *out when (fx,fy) belongs to
 * the apple or the progress bar; FALSE means "plain background".
 *
 * This used to return a negative sentinel through int, which was a bug that
 * erased the artwork outright: the old white was 0xffffffffu, and as a signed
 * int that is -1, so every lit pixel of the apple was painted black. The apple
 * was never missing, it was being drawn in the background colour. The palette
 * lookup below cannot repeat that: logo_palette[] is uint32_t.
 */
static boolean_t
sweet_art_pixel(unsigned int fx, unsigned int fy, unsigned int bar_fill,
    boolean_t under_text __unused, uint32_t *out)
{
	if (fx >= LOGO_X && fx < LOGO_X + LOGO_W &&
	    fy >= LOGO_Y && fy < LOGO_Y + LOGO_H_PX) {
		*out = LOGO_RGB(logo_pixel((int)(fx - LOGO_X),
		    (int)(fy - LOGO_Y)));
		return TRUE;
	}
	if (fy >= BAR_Y && fy < BAR_Y + BAR_H_PX &&
	    fx >= BAR_X && fx < BAR_X + BAR_W) {
		*out = (fx - BAR_X) < bar_fill ? BAR_FILL : BAR_TRACK;
		return TRUE;
	}
	return FALSE;
}

static void
sweet_early_clear_row(void)
{
	unsigned int top = early_row * EARLY_CELL_H;
	unsigned int bottom = top + EARLY_CELL_H;
	boolean_t over_apple = !(bottom <= LOGO_Y || top >= LOGO_Y + LOGO_H_PX);

	if (!over_apple) {
		for (unsigned int y = 0; y < EARLY_CELL_H; y++) {
			volatile uint32_t *line = EARLY_FB + (top + y) * EARLY_STRIDE;
			for (unsigned int x = 0; x < EARLY_WIDTH; x++) {
				line[x] = LOGO_BLACK;
			}
		}
		return;
	}
	for (unsigned int y = 0; y < EARLY_CELL_H; y++) {
		unsigned int fy = top + y;
		volatile uint32_t *line = EARLY_FB + fy * EARLY_STRIDE;
		for (unsigned int x = 0; x < EARLY_WIDTH; x++) {
			uint32_t c;
			line[x] = sweet_art_pixel(x, fy, sweet_bar_fill_static,
			    TRUE, &c) ? c : LOGO_BLACK;
		}
	}
}

void
sweet_early_putc(char c)
{
	if (early_disabled) {
		return;
	}
	/*
	 * SWEET (7195 port): mirror panic output into the UFS console ring
	 * (bsd/dev/sweet_ufs.c) so it can be persisted and read later from TWRP.
	 * Without this a dead screen leaves no evidence at all.
	 */
	if (early_panicking) {
		extern void sweet_log_append(const char *c, int size);
		sweet_log_append(&c, 1);
	}
	if (!early_started) {
		early_started = 1;
		/*
		 * SWEET (7195 port): black the whole screen, paint the artwork once,
		 * then clear the first row through the same helper the scroll uses
		 * (it repaints any artwork the row covers).
		 */
		for (unsigned int y = 0; y < EARLY_BAR_TOP; y++) {
			volatile uint32_t *line = EARLY_FB + y * EARLY_STRIDE;
			for (unsigned int x = 0; x < EARLY_WIDTH; x++) {
				line[x] = LOGO_BLACK;
			}
		}
		sweet_early_paint_logo();
		sweet_early_clear_row();
	}
	if (c == '\r') {
		early_col = 0;
		return;
	}
	if (c == '\n' || early_col == EARLY_COLS) {
		early_col = 0;
		/*
		 * SWEET (7195 port): wrap the cursor, do not scroll.
		 *
		 * Copying the text region up one cell looks like a real terminal
		 * scroll, but this framebuffer is mapped Normal Non-Cacheable: the
		 * move touches 57*32*1440 = 2.6 M uncached words per line, ~50 ms
		 * each. With a few thousand lines during the HFS walk that turned
		 * the boot into minutes and pushed past launchd's task timeouts
		 * (observed: fsck at 36 s, mount-phase-1 at 46 s, still in
		 * usermanagerd at 4 min). Wrapping costs one row clear.
		 *
		 * The artwork is not avoided any more: sweet_early_clear_row()
		 * repaints whatever part of it a row covers, so text can pass over
		 * the apple and the progress bar while they stay put.
		 */
		early_row = (early_row + 1) % EARLY_ROWS;
		sweet_early_clear_row();
		if (c == '\n') {
			return;
		}
	}
	const unsigned char *glyph = iso_font + (unsigned char)c * 16;
	for (unsigned int gy = 0; gy < 16; gy++) {
		for (unsigned int sy = 0; sy < EARLY_SCALE; sy++) {
			volatile uint32_t *line = EARLY_FB +
			    (early_row * EARLY_CELL_H + gy * EARLY_SCALE + sy) * EARLY_STRIDE +
			    early_col * EARLY_CELL_W;
			for (unsigned int gx = 0; gx < 8; gx++) {
				if (glyph[gy] & (1u << gx)) {
					/*
					 * SWEET (7195 port): lit pixels are the only ones
					 * written; the background is left as drawn so the
					 * logo shows through the text, as on a real boot.
					 */
					for (unsigned int sx = 0; sx < EARLY_SCALE; sx++) {
						line[gx * EARLY_SCALE + sx] = 0xffffffffu;
					}
				}
			}
		}
	}
	early_col++;
}

static void
sweet_early_string(const char *s)
{
	while (*s) {
		sweet_early_putc(*s++);
	}
}


void
sweet_early_mark(unsigned int stage, const char *label)
{
	if (early_disabled) {
		return;
	}
	/*
	 * SWEET (7195 port): mac-style progress bar under the apple.
	 *
	 * The fill amount is kept in sweet_bar_fill_static, because it is part of
	 * the artwork now: a row of text scrolling over the bar repaints it with
	 * whatever fill was current. Updating the variable and repainting the
	 * strip through the same helper keeps the two paths in agreement, and the
	 * strip is only 360x8 px, so this stays cheap.
	 */
	{
		unsigned int fill = BAR_W * (stage % 30u) / 29u;
		if (fill > BAR_W) {
			fill = BAR_W;
		}
		sweet_bar_fill_static = fill;
		for (unsigned int y = BAR_Y; y < BAR_Y + BAR_H_PX; y++) {
			volatile uint32_t *line = EARLY_FB + y * EARLY_STRIDE;
			for (unsigned int x = BAR_X; x < BAR_X + BAR_W; x++) {
				line[x] = (x - BAR_X) < fill ? BAR_FILL : BAR_TRACK;
			}
		}
	}
	__asm__ volatile("dsb sy" ::: "memory");
	/*
	 * SWEET (7195 port): record the stage in the crumb page the shim reads
	 * on the next boot. A hang before the UFS log exists leaves nothing
	 * else behind; see s9port/shim/crumbs.h for the layout.
	 */
	{
		volatile uint32_t *c = (volatile uint32_t *)(uintptr_t)0x9d000000UL;
		if ((c[0] & 0xffffff00U) == 0x53574300U) {
			c[0] = 0x53574300U | (stage & 0xffU);
			c[2] = stage;
		}
	}
	sweet_early_string("SWEET EARLY ");
	/*
	 * SWEET (7195 port): three digits. The previous form wrote only
	 * tens and units, so every mark >= 100 printed as ':' + units:
	 * 100 became ":0", 106 became ":6", 113 became ":3". That made
	 * every screen reading past mark 99 wrong. Marks up to 999 fit.
	 */
	if (stage >= 100) {
		sweet_early_putc((char)('0' + (stage / 100) % 10));
	}
	if (stage >= 10) {
		sweet_early_putc((char)('0' + (stage / 10) % 10));
	}
	sweet_early_putc((char)('0' + stage % 10));
	sweet_early_string(": ");
	sweet_early_string(label);
	sweet_early_putc('\n');
}

static void
sweet_early_hex(uint64_t v)
{
	sweet_early_string("0x");
	for (int shift = 60; shift >= 0; shift -= 4) {
		unsigned int d = (unsigned int)((v >> shift) & 0xf);
		sweet_early_putc((char)(d < 10 ? '0' + d : 'a' + (d - 10)));
	}
}

/* Formatted line on the early console. bsd_init's own printf() does not reach
 * the screen on this port (vcputc needs gc_initialized, which the SWEET path
 * never sets), so anything that must be read off a photo goes through here.
 */
void
sweet_early_printf(const char *fmt, ...)
{
	if (early_disabled) {
		return;
	}
	va_list ap;
	va_start(ap, fmt);
	_doprnt(fmt, &ap, sweet_early_putc, 16);
	va_end(ap);
	sweet_early_putc('\n');
}

void
sweet_early_panic(const char *fmt, va_list *args)
{
	if (early_disabled || early_panicking) {
		return;
	}
	early_panicking = 1;
	sweet_early_string("\nSWEET EARLY PANIC: ");
	va_list copy;
	va_copy(copy, *args);
	_doprnt(fmt, &copy, sweet_early_putc, 16);
	va_end(copy);
	sweet_early_putc('\n');
	/*
	 * Which CPU faulted, and how we got here. A data abort reported with the
	 * same pc/lr across boots while the mark progress differs is a fault on a
	 * secondary CPU or in an interrupt, not on the line the last mark names.
	 */
	sweet_early_string("SWEET PANIC CPU ");
	sweet_early_hex((uint64_t)__builtin_arm_rsr64("MPIDR_EL1"));
	sweet_early_putc('\n');

	uint64_t *fp = (uint64_t *)__builtin_frame_address(0);
	for (int i = 0; i < 16; i++) {
		uint64_t fpv = (uint64_t)(uintptr_t)fp;
		if (fpv < 0xffffffe000000000ULL || fpv > 0xfffffffbffffffffULL || (fpv & 7u)) {
			break;
		}
		uint64_t lr = fp[1];
		uint64_t *next = (uint64_t *)(uintptr_t)fp[0];
		sweet_early_string("SWEET BT ");
		sweet_early_hex(lr);
		sweet_early_putc('\n');
		if ((uint64_t)(uintptr_t)next <= fpv) {
			break;
		}
		fp = next;
	}
	/*
	 * SWEET (7195 port): persist the ring to sda29 now (see
	 * bsd/dev/sweet_ufs.c sweet_log_flush_panic). The periodic flush thread
	 * never runs before a panic, so without this the partition header stays
	 * at the previous kernel's totals and the panic is only ever visible as
	 * a photo of this screen.
	 */
	{
		extern void sweet_log_flush_panic(void);
		sweet_log_flush_panic();
	}
	/*
	 * SWEET (7195 port): after a panic, put the phone back in TWRP by itself.
	 *
	 * The Android bootloader reads the command block at the start of `misc`;
	 * writing "boot-recovery" there makes the next boot go to recovery
	 * instead of the kernel. Without this every round needs a human to press
	 * the key combination, which is what has been costing most of the time in
	 * this project. bsd/dev/sweet_bcb.c holds the geometry and the format.
	 */
	{
		extern void sweet_bcb_request_recovery(void);
		sweet_bcb_request_recovery();
	}
	__asm__ volatile("dsb sy" ::: "memory");
}

void
sweet_early_relocate(uint64_t base)
{
	sweet_early_mark(8, "leaving bootstrap TTBR0");
	early_fb = (volatile uint32_t *)(uintptr_t)base;
	__asm__ volatile("dsb sy" ::: "memory");
	sweet_early_mark(9, "kernel framebuffer VA live");
}

void
sweet_early_disable(void)
{
	early_disabled = 1;
	__asm__ volatile("dsb sy" ::: "memory");
}
#endif /* SWEET */
