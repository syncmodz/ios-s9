/*
 * SWEET (7195 port): the 8796 line carries this file, which stores the AMFI
 * interface registered by the built-in provider (bsd/kern/sweet_amfi.c calls
 * amfi_interface_register at EARLY_BOOT). This line has the same header but
 * not the implementation.
 */
#include <libkern/libkern.h>
#include <libkern/section_keywords.h>
#include <libkern/amfi/amfi.h>

SECURITY_READ_ONLY_LATE(const amfi_t *) amfi = NULL;

void
amfi_interface_register(const amfi_t *mfi)
{
	if (amfi) {
		panic("AppleMobileFileIntegrity interface already set");
	}
	amfi = mfi;
}
